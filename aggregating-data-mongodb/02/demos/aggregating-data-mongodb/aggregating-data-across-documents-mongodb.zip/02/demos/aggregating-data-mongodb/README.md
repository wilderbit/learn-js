# aggregating-data-mongodb

This materials are in the github repository https://github.com/axel-sirota/aggregating-data-mongodb.


Resources and demos for Aggregating Data Across Documents in MongoDB @ Pluralsight
